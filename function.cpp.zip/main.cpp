#include <stdio.h>
#include<iostream>
int add(int a, int b) //function dclaration \\ singnature function
{
    int c;                    //*bidy *//
    c=a+b;
     return(c);
}
int main(){
    int x,y,z;
    x=15;
    y=20;
    z=add(x,y); //function call
    printf("Addition is %d",+z);
}