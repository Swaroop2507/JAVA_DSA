/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
//call by value
using namespace std;
int add(int a, int b){
    a++;
    cout<<a;
    int c;
    c=a/b;
    return(c);
}

int main()
{
    int x,y,sum;
    x=10;
    y=29;
    sum = add(x,y);
    cout<<endl<<x<<endl;
    
    cout<<"Hello World";

    return 0;
}