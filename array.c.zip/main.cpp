/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int A[100]={2,25,7,8};// array initialization
    
    cout<<sizeof(A)<<endl;
    cout<<A[2]<<endl;
    printf("%d\n",A[3]);
    // if the element are not present in the place then it is set as 0 ex A[7]=0
    

    return 0;
}