import java.util.*;

public class Main
{
	public static void main(String[] args) {
	    int[] marks=new int[3];
	    marks[0]=97;
	    marks[1]=96;
	    marks[2]=99;
	    for(int i=0;i<3;i ++){
	    System.out.println(marks[i]);
	    }
}
}